# Calc
A simple package anyone can use to add mathematical functions to their python code. Have fun :)


